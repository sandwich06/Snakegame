package Client;

public class Snake {
	/*
	status1: head to right
	status2: head to up
	status3: head to left
	status4: head to down
	
	status5: body horizontal
	status6: body vertical
	
	status7: from down turn right
	status8: from right turn up 
	status9: from up turn left
	status10: from left turn down
	
	status11: tail to right 
	status12: tail to left
	status13: tail to up
	status14: tail to down
	*/
	private int x;
	private int y;
	private int status;
	private int prev_status;
	
	public Snake() {
		
	}
	
	public Snake(int x,int y, int status) {
		this.x=x;
		this.y=y;
		this.status=status;
		this.setPrev_status(status);
	}

	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}


	public int getPrev_status() {
		return prev_status;
	}


	public void setPrev_status(int prev_status) {
		this.prev_status = prev_status;
	}
	
	
}
