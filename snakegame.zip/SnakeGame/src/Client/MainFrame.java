package Client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 


public class MainFrame extends JFrame{

	private static int WIDTH = 700;
	private static int HEIGHT = 450;
	
	private BackgroundPanel bgp;
	private JButton single_model;
	private JButton rank;
	private JButton exit;
	
	public MainFrame() {
		this.setSize(MainFrame.WIDTH, MainFrame.HEIGHT);
		
		//getContentPane().setLayout(null);
		
		createSingleModel();
		createRank();
		createExit();
		
		bgp = new BackgroundPanel(new ImageIcon("resource\\images\\mainFrameBG.png").getImage());
		getContentPane().add(bgp);
		

		this.setTitle("Snake Game");
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setResizable(false);
	}
	
	public void createSingleModel() {
		single_model = new JButton("Start Play");
		single_model.setBounds((int)(this.getWidth()*0.18), (int)(this.getHeight()*0.7),130, 40);
		single_model.setContentAreaFilled(false);
		single_model.setFocusPainted(false);
		single_model.setFont(new Font("Times New Roman", Font.BOLD, 20));
		single_model.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlayFrame pf = new PlayFrame();
				pf.setVisible(true);
				new Thread(pf).start();
			}
		});
		getContentPane().add(single_model);
	}
	
	public void createRank() {
		rank = new JButton("Rank");
		rank.setBounds((int)(this.getWidth()*0.40), (int)(this.getHeight()*0.7), 130, 40);
		rank.setContentAreaFilled(false);
		rank.setFocusPainted(false);
		rank.setFont(new Font("Times New Roman", Font.BOLD, 20));
		rank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rank rank = new Rank();
				rank.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				rank.setVisible(true);	
			}
		});
		getContentPane().add(rank);
	}
	
	public void createExit() {
		exit = new JButton("Exit");
		exit.setBounds((int)(this.getWidth()*0.63), (int)(this.getHeight()*0.7), 130, 40);
		exit.setContentAreaFilled(false);
		exit.setFocusPainted(false);
		exit.setFont(new Font("Times New Roman", Font.BOLD, 20));
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		getContentPane().add(exit);
	}
	
	public static void main(String[] args) {
		MainFrame mf = new MainFrame();
		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mf.setVisible(true);
	}
	
	class BackgroundPanel extends JPanel {
		Image im;
	public BackgroundPanel(Image im) {
	   this.im=im;
	   this.setOpaque(true);
	}
	//Draw the back ground.
	public void paintComponent(Graphics g){
	   super.paintComponents(g);
	   g.drawImage(im,0,0,this.getWidth(),this.getHeight(),this);
	   }
	}
}
