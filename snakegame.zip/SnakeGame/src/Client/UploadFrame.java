package Client;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class UploadFrame extends JFrame{
	
	
	private int score=0;
	private Socket playerSocket;
	private JButton upload;
	private JTextField name;
	
	public UploadFrame(int score) {
		setTitle("Upload Score");
		this.setSize(605, 341);
		this.score = score;
		this.setResizable(false);
		
		upload = new JButton();
		upload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pname = name.getText();
				if(!pname.isEmpty()) {
					try {
						playerSocket = new Socket("localhost",9898);
						PrintWriter writer = getWriter(playerSocket);
						writer.write("1\n");
						writer.write(pname+"\n");
						writer.write(score+"\n");
						writer.flush();
						JOptionPane.showMessageDialog(null, "Upload Successful!", "",JOptionPane.PLAIN_MESSAGE);
						dispose();
						
					} catch (IOException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "No Connection!", "Error",JOptionPane.ERROR_MESSAGE); 
					}finally {
						
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Name is empty!", "Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		upload.setText("Upload");
		upload.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		upload.setBounds(166, 201, 228, 52);
		getContentPane().setLayout(null);
		name = new JTextField();
		name.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		name.setBounds(135, 122, 367, 52);
		
		
		
		getContentPane().add(name);
		getContentPane().add(upload);
		
		JLabel nameLabel = new JLabel("Name:");
		nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		nameLabel.setBounds(34, 130, 116, 44);
		getContentPane().add(nameLabel);
		
		JLabel lblNewLabel = new JLabel("Your Score: " + score);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel.setBounds(135, 47, 301, 44);
		getContentPane().add(lblNewLabel);
		
		
	}
	
	private BufferedReader getReader(Socket socket) throws IOException {
	    InputStream in = socket.getInputStream();
	    return new BufferedReader(new InputStreamReader(in));
	}

	private PrintWriter getWriter(Socket socket) throws IOException {
	    OutputStream out = socket.getOutputStream();
	    return new PrintWriter(new OutputStreamWriter(out));
	}
	
	public static void main(String[] args) {
		UploadFrame up = new UploadFrame(10);
		up.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		up.setVisible(true);
	}
}
