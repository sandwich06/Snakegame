package Client;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.*;

public class PlayFrame extends JFrame implements Runnable{
	
	private static int WIDTH = 700;
	private static int HEIGHT = 640;
	
    private final int B_WIDTH = 540;
    private final int B_HEIGHT = 540;
    private final int DOT_SIZE = 18;
    private final int ALL_DOTS = 625;
    private final int RAND_POS = B_WIDTH/DOT_SIZE;
    private final int SNAKE_LENGTH = 18;
    private final int[][] graph = new int[B_WIDTH/DOT_SIZE][B_HEIGHT/DOT_SIZE];
    
    private PlayPanel pp;
    private JPanel top;
    
    private ArrayList<Snake> snakes= new ArrayList();
    private int dots;
    private int apple_x;
    private int apple_y;
    public static int score=0;
    
    private Timer timer;
    
    private boolean inGame = true;
    
    BufferedImage apple;
    BufferedImage snake_head;
    BufferedImage snake_body;
    BufferedImage snake_tail;
    BufferedImage turn_body;
    BufferedImage tail;
	
	public PlayFrame() {
		
		this.setSize(WIDTH, HEIGHT);
		
		addKeyListener(new TAdapter());
		
		getContentPane().setLayout(null);
		getContentPane().setBackground(Color.BLACK);
		loadImages();
		initGame();
		
		pp = new PlayPanel();
		pp.setSize(B_WIDTH, B_HEIGHT);
		pp.setBounds(70, 50, B_WIDTH, B_HEIGHT);
		pp.setBackground(Color.GRAY);
		
		top = new ScorePanel();
		top.setSize(500, 45);
		top.setBounds(100, 5, 500, 40);
		top.setBackground(Color.BLACK);
		
		
		getContentPane().add(pp);
		getContentPane().add(top);
		getContentPane();
		
		
		
	}
	
	 private void loadImages() {
		 try {
			 apple = ImageIO.read(new File("resource\\images\\apple.png"));
			 System.out.println(apple);
			 
			 snake_head = ImageIO.read(new File("resource\\images\\head.png"));
	
			 snake_body = ImageIO.read(new File("resource\\images\\body.png"));
			 
			 turn_body = ImageIO.read(new File("resource\\images\\turnbody.png"));
			 
			 tail = ImageIO.read(new File("resource\\images\\tail.png"));
		 }catch (IOException e) {
				e.printStackTrace();
			}
	 }
	 
	 private void initGame() {
		 
		 score=0;
		 
		 for (int i = 0; i < graph.length; i++) {
             for (int j = 0; j < graph[i].length; j++) {
                 graph[i][j] = 0;
             }
         }
		 
		 InitSnake();
		 updateGraph();
		 //graph[RAND_POS/2-3][RAND_POS/2]=3;
		 
		 createApple();
	 }
	 
	 public void InitSnake() {
		 snakes.clear();
		 snakes.add(new Snake(RAND_POS/2,RAND_POS/2,1));
		 snakes.add(new Snake(RAND_POS/2-1,RAND_POS/2,5));
		 snakes.add(new Snake(RAND_POS/2-2,RAND_POS/2,5));
		 snakes.add(new Snake(RAND_POS/2-3,RAND_POS/2,12));
	 }
	 
	 public void updateGraph() {
		 for (int i = 0; i < graph.length; i++) {
             for (int j = 0; j < graph[i].length; j++) {
                 graph[i][j] = 0;
             }
         }
		 for(Snake snake:snakes) {
			 graph[snake.getX()][snake.getY()]=snake.getStatus();
		 }
		 graph[apple_x][apple_y]=99;
	 }
	 
	 public void checkCollision() {
		 if(snakes.get(0).getX()>=graph.length || snakes.get(0).getX()<0||snakes.get(0).getY()<0 || snakes.get(0).getY()>=graph.length) {
			 inGame=false;
		 }
		 for(int i = 1; i<snakes.size();i++) {
			 if(snakes.get(0).getX()==snakes.get(i).getX() && snakes.get(0).getY()==snakes.get(i).getY()) {
				 inGame=false;
			 }
		 }
	 }
	 
	 public void checkApple(Snake s2,Snake s1) {
		 if (snakes.get(0).getX()==apple_x && snakes.get(0).getY()==apple_y) {
			 snakes.remove(snakes.size()-1);
			 snakes.add(s2);
			 snakes.add(s1);
			 createApple();
			 score++;
		 }
	 }
	 
	 public void createApple() {
		 while(true) {
			 apple_x = (int) (Math.random() * RAND_POS);
			 apple_y = (int) (Math.random() * RAND_POS);
			 
			 int i=0;
		     	
			 for(Snake snake:snakes) {
				 if(apple_x==snake.getX() && apple_y==snake.getY()) {
					 i=1;
				 }
			 }
			 if(i==0)
				 break;
		 }
	     
	     graph[apple_x][apple_y]=99;
	 }
	 
	 public void move() {
		 Snake s1= new Snake(snakes.get(snakes.size()-1).getX(),snakes.get(snakes.size()-1).getY(),snakes.get(snakes.size()-1).getStatus());
		 Snake s2= new Snake(snakes.get(snakes.size()-2).getX(),snakes.get(snakes.size()-2).getY(),snakes.get(snakes.size()-2).getStatus());
		 for(int i = snakes.size()-1;i>=0;i--) {
			 Snake snake = snakes.get(i);
			 if(1<=snake.getStatus() && snake.getStatus()<=4) {
				 int status = snake.getStatus();
				 if(status==1) {
					 snake.setX(snake.getX()+1);
				 }
				 else if(status==2) {
					 snake.setY(snake.getY()-1);
				 }
				 else if(status==3) {
					 snake.setX(snake.getX()-1);
				 }
				 else if(status==4) {
					 snake.setY(snake.getY()+1);
				 }
				 snake.setPrev_status(status);
			 }
			 else if (5<=snake.getStatus() && snake.getStatus()<=10) {
				 snakes.get(i).setX(snakes.get(i-1).getX());
				 snakes.get(i).setY(snakes.get(i-1).getY());
				 if(i!=1) {
					 snakes.get(i).setStatus(snakes.get(i-1).getStatus());
				 }
				 else {
					 if(snake.getStatus()==5) {
						 if(snakes.get(i-1).getStatus()==1 || snakes.get(i-1).getStatus()==3) {
							 
						 }
						 else {
							 if(snakes.get(i-1).getStatus()==2 && snakes.get(i-1).getPrev_status()==1) {
								 snakes.get(i).setStatus(9);
							 }
							 else if(snakes.get(i-1).getStatus()==2 && snakes.get(i-1).getPrev_status()==3) {
								 snakes.get(i).setStatus(8);
							 }
							 else if(snakes.get(i-1).getStatus()==4 && snakes.get(i-1).getPrev_status()==1) {
								 snakes.get(i).setStatus(10);
							 }
							 else if(snakes.get(i-1).getStatus()==4 && snakes.get(i-1).getPrev_status()==3) {
								 snakes.get(i).setStatus(7);
							 }
						 }
					 }
					 else if(snake.getStatus()==6) {
						 if(snakes.get(i-1).getStatus()==2 || snakes.get(i-1).getStatus()==4) {
							 
						 }
						 else {
							 if(snakes.get(i-1).getStatus()==1 && snakes.get(i-1).getPrev_status()==2) {
								 snakes.get(i).setStatus(7);
							 }
							 else if(snakes.get(i-1).getStatus()==1 && snakes.get(i-1).getPrev_status()==4) {
								 snakes.get(i).setStatus(8);
							 }
							 else if(snakes.get(i-1).getStatus()==3 && snakes.get(i-1).getPrev_status()==2) {
								 snakes.get(i).setStatus(10);
							 }
							 else if(snakes.get(i-1).getStatus()==3 && snakes.get(i-1).getPrev_status()==4) {
								 snakes.get(i).setStatus(9);
							 }
						 }
					 }
					 else{
						 if(snakes.get(i-1).getStatus()==4 && snakes.get(i-1).getPrev_status()==4) {
							 snakes.get(i).setStatus(6);
						 }
						 else if(snakes.get(i-1).getStatus()==2 && snakes.get(i-1).getPrev_status()==2) {
							 snakes.get(i).setStatus(6);
						 }
						 else if(snakes.get(i-1).getStatus()==1 && snakes.get(i-1).getPrev_status()==1) {
							 snakes.get(i).setStatus(5);
						 }
						 else if(snakes.get(i-1).getStatus()==3 && snakes.get(i-1).getPrev_status()==3) {
							 snakes.get(i).setStatus(5);
						 }
						 else if(snakes.get(i-1).getStatus()==2 && snakes.get(i-1).getPrev_status()==1) {
							 snakes.get(i).setStatus(9);
						 }
						 else if(snakes.get(i-1).getStatus()==2 && snakes.get(i-1).getPrev_status()==3) {
							 snakes.get(i).setStatus(8);
						 }
						 else if(snakes.get(i-1).getStatus()==4 && snakes.get(i-1).getPrev_status()==1) {
							 snakes.get(i).setStatus(10);
						 }
						 else if(snakes.get(i-1).getStatus()==4 && snakes.get(i-1).getPrev_status()==3) {
							 snakes.get(i).setStatus(7);
						 }
						 else if(snakes.get(i-1).getStatus()==1 && snakes.get(i-1).getPrev_status()==2) {
							 snakes.get(i).setStatus(7);
						 }
						 else if(snakes.get(i-1).getStatus()==1 && snakes.get(i-1).getPrev_status()==4) {
							 snakes.get(i).setStatus(8);
						 }
						 else if(snakes.get(i-1).getStatus()==3 && snakes.get(i-1).getPrev_status()==2) {
							 snakes.get(i).setStatus(10);
						 }
						 else if(snakes.get(i-1).getStatus()==3 && snakes.get(i-1).getPrev_status()==4) {
							 snakes.get(i).setStatus(9);
						 }
					 }
				 }
			 }
			 else if(snake.getStatus()==11) {
				 snakes.get(i).setX(snakes.get(i-1).getX());
				 snakes.get(i).setY(snakes.get(i-1).getY());
				 if(snakes.get(i-1).getStatus()==7) {
					 snakes.get(i).setStatus(13); 
				 }
				 else if(snakes.get(i-1).getStatus()==8) {
					 snakes.get(i).setStatus(14);
				 }
			 }
			 else if(snake.getStatus()==12) {
				 snakes.get(i).setX(snakes.get(i-1).getX());
				 snakes.get(i).setY(snakes.get(i-1).getY());
				 if(snakes.get(i-1).getStatus()==9) {
					 snakes.get(i).setStatus(14);
				 }
				 else if(snakes.get(i-1).getStatus()==10) {
					 snakes.get(i).setStatus(13);
				 }
			 }
			 else if(snake.getStatus()==13) {
				 snakes.get(i).setX(snakes.get(i-1).getX());
				 snakes.get(i).setY(snakes.get(i-1).getY());
				 if(snakes.get(i-1).getStatus()==8) {
					 snakes.get(i).setStatus(12);
				 }
				 else if(snakes.get(i-1).getStatus()==9) {
					 snakes.get(i).setStatus(11);
				 }
			 }
			 else if(snake.getStatus()==14) {
				 snakes.get(i).setX(snakes.get(i-1).getX());
				 snakes.get(i).setY(snakes.get(i-1).getY());
				 if(snakes.get(i-1).getStatus()==7) {
					 snakes.get(i).setStatus(12);
				 }
				 else if(snakes.get(i-1).getStatus()==10) {
					 snakes.get(i).setStatus(11);
				 }
			 }
		 }
		 checkApple(s2,s1);
	 }
	 
	 
	 class PlayPanel extends JPanel {
		 public PlayPanel() {
			 
		 }
		 
		 public void paintComponent(Graphics g) {
			 super.paintComponent(g);
			 doDrawing(g);
		 }
		 
		 public void doDrawing(Graphics g) {
			 
			 for (int i = 0; i < graph.length; i++) {
	             for (int j = 0; j < graph[i].length; j++) {
	                 if(graph[i][j]==99) {
	                	 g.drawImage(apple, (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==1) {
	                	 g.drawImage(snake_head, (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==2) {
	                	 g.drawImage(ImageUtils.rotateImage(snake_head,-90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==3) {
	                	 g.drawImage(ImageUtils.rotateImage(snake_head,180), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==4) {
	                	 g.drawImage(ImageUtils.rotateImage(snake_head,90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==5) {
	                	 g.drawImage(snake_body, (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==6) {
	                	 g.drawImage(ImageUtils.rotateImage(snake_body,-90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==7) {
	                	 g.drawImage(turn_body, (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==8) {
	                	 g.drawImage(ImageUtils.rotateImage(turn_body,-90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==9) {
	                	 g.drawImage(ImageUtils.rotateImage(turn_body,180), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==10) {
	                	 g.drawImage(ImageUtils.rotateImage(turn_body,90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==11) {
	                	 g.drawImage(tail, (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==12) {
	                	 g.drawImage(ImageUtils.rotateImage(tail,180), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==13) {
	                	 g.drawImage(ImageUtils.rotateImage(tail,-90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	                 else if(graph[i][j]==14) {
	                	 g.drawImage(ImageUtils.rotateImage(tail,90), (i)*DOT_SIZE, (j)*DOT_SIZE, SNAKE_LENGTH, SNAKE_LENGTH,this);
	                 }
	             }
	         }
			 
		 }
	  }
	 
	 class ScorePanel extends JPanel{
		 public ScorePanel() {
			 
		 }
		 public void paintComponent(Graphics g) {
			 super.paintComponent(g);
			 doDrawing(g);
		 }
		 
		 public void doDrawing(Graphics g) {
			 g.drawImage(apple, 1, 1, 30, 30,this);
			 String text="  X   "+String.valueOf(score);
			 g.setFont(new Font("Times New Roman", Font.BOLD, 30));
			 g.setColor(Color.RED);
			 g.drawString(text, 40, 29);
		 }
		 
	 }
	 
	 private class TAdapter extends KeyAdapter {

	        @Override
	        public void keyPressed(KeyEvent e) {

	            int key = e.getKeyCode();

	            if ((key == KeyEvent.VK_LEFT) && (snakes.get(0).getStatus()!=1)) {
	            	snakes.get(0).setPrev_status(snakes.get(0).getStatus());
	            	snakes.get(0).setStatus(3);
	            }

	            if ((key == KeyEvent.VK_RIGHT) && (snakes.get(0).getStatus()!=3)) {
	            	snakes.get(0).setPrev_status(snakes.get(0).getStatus());
	            	snakes.get(0).setStatus(1);
	            }

	            if ((key == KeyEvent.VK_UP) && (snakes.get(0).getStatus()!=4)) {
	            	snakes.get(0).setPrev_status(snakes.get(0).getStatus());
	            	snakes.get(0).setStatus(2);
	            }

	            if ((key == KeyEvent.VK_DOWN) && (snakes.get(0).getStatus()!=2)) {
	            	snakes.get(0).setPrev_status(snakes.get(0).getStatus());
	            	snakes.get(0).setStatus(4);
	            }

	        }
	    }
	 
	 public void run() {
			while(inGame) {
				top.repaint();
				pp.repaint();
				move();
				checkCollision();
				if(!inGame) {
					System.out.println("over");
					JOptionPane.showMessageDialog(null, "Game over!");
					UploadFrame up = new UploadFrame(score);
					up.setVisible(true);
					System.out.println(up.isShowing());
					while(up.isShowing()) {
					}
					Object[] options ={ "Play again!", "Exit" }; 
					int m = JOptionPane.showOptionDialog(null, "Start a new game", "New game",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);  
					if(m==0) {
						inGame = true;
						initGame();
					}
					else {
						dispose();
					}
					
				}
				updateGraph();
				
				try {
					Thread.sleep(80);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	 }
	 
	public static void main(String[] args) {
		PlayFrame pf = new PlayFrame();
		pf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pf.setVisible(true);
		new Thread(pf).start();
	}

}
