package Client;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import Server.Player;

public class Rank extends JFrame{
	private JTable table;
	private Socket rankSocket;
	
	public Rank() {
		this.setSize(550,600);
		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable(){
            public boolean isCellEditable(int row, int column)
            {
            	return false;}
            };
		DefaultTableModel dtm = new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Rank", "Name", "Score"
				}
			);
		table.setModel(dtm);
		table.getColumnModel().getColumn(0).setResizable(false);
		table.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		ArrayList<Player> players = getRank();
		players.sort((a,b) -> b.getScore()- a.getScore());
		
		dtm.setNumRows(players.size());
		
		for(int i = 0; i<players.size();i++) {

			table.getModel().setValueAt(i+1, i, 0);
			table.getModel().setValueAt(players.get(i).getName(), i, 1);
			table.getModel().setValueAt(players.get(i).getScore(), i, 2);
		}
		
		scrollPane.setViewportView(table);
	}
	
	public ArrayList<Player> getRank(){
		ArrayList<Player> players = new ArrayList();
		try {
			rankSocket = new Socket("localhost",9898);
			BufferedReader reader = getReader(rankSocket);
			PrintWriter writer = getWriter(rankSocket);
			writer.write("2\n");
			writer.flush();
            
            
            
            int size = Integer.valueOf(reader.readLine());
            for(int i = 0;i<size;i++) {
            	String name = reader.readLine();
            	int score = Integer.valueOf(reader.readLine());
            	players.add(new Player(name,score));
            }
            rankSocket.close();
			
		} catch (IOException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "No Connection!", "Error",JOptionPane.ERROR_MESSAGE); 
		}finally {
			
		}
		return players;
	}
	
	private BufferedReader getReader(Socket socket) throws IOException {
	    InputStream in = socket.getInputStream();
	    return new BufferedReader(new InputStreamReader(in));
	}

	private PrintWriter getWriter(Socket socket) throws IOException {
	    OutputStream out = socket.getOutputStream();
	    return new PrintWriter(new OutputStreamWriter(out));
	}
	
	
	public static void main(String[] args) {
		Rank rank = new Rank();
		rank.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		rank.setVisible(true);
	}
	
}
