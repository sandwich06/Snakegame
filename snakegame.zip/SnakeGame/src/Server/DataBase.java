package Server;

import java.sql.*;

public class DataBase {
	private String dbUrl = "jdbc:mysql://localhost:3306/snakegame?serverTimezone=America/New_York";
	private String dbUser = "root";
	private String dbPassword = "123";
	private String jdbcName = "com.mysql.jdbc.Driver";
	private Connection connection = null;
	
	public Connection getConnection(){
		try {
			Class.forName(jdbcName);
			connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			System.out.println("Connect Successful!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Connect Failed!");
			e.printStackTrace();
		}
		return connection;
	}
	
	public void closeCon(){
		if(connection != null)
			try {
				connection.close();
				System.out.println("Connection Closed!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static void main(String[] args) {
		DataBase db = new DataBase();
		db.getConnection();
	}
}
