package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;


public class Server implements Runnable{
	private DataBase database;
	private Connection connection;
	private int clientNo = 0;
	List<Socket> sockets = new Vector<>();
	
	public Server() {
		database = new DataBase();
		connection = database.getConnection();
	}
	
	public ArrayList<Player> selectAll() {
		ArrayList<Player> rank = new ArrayList<>();
		
		try {
			Statement statement = connection.createStatement();
			
			String sql = "SELECT * FROM `rank`";
            ResultSet resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
            	rank.add(new Player(resultSet.getString("name"),resultSet.getInt("score")));
            }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rank;
		
	}
	
	public boolean InsertRecord(Player player) {
		Statement statement;
		try {
			statement = connection.createStatement();
			String sql="INSERT INTO `rank` (`name`, `score`) VALUES ('"+player.getName()+"', '"+player.getScore()+"');";
	        statement.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	@Override
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(9898);
			System.out.println("Server started at " + new Date() + '\n');
			
			while(true) {
				Socket accept = serverSocket.accept();
				
				synchronized (sockets){
					sockets.add(accept);
				}
				
				clientNo++;
		          
				System.out.println("Starting thread for client " + clientNo + " at " + new Date() + '\n');
				
				InetAddress inetAddress = accept.getInetAddress();
				System.out.println("Client " + clientNo + "'s host name is " + inetAddress.getHostName() + "\n");
				System.out.println("Client " + clientNo + "'s IP Address is "+ inetAddress.getHostAddress() + "\n");
				
				new Thread(new ServerThread(accept,clientNo)).start();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	private BufferedReader getReader(Socket socket) throws IOException {
	    InputStream in = socket.getInputStream();
	    return new BufferedReader(new InputStreamReader(in));
	}

	private PrintWriter getWriter(Socket socket) throws IOException {
	    OutputStream out = socket.getOutputStream();
	    return new PrintWriter(new OutputStreamWriter(out));
	}
	
	class ServerThread implements Runnable {
	    private Socket socket; // A connected socket
	    private int clientNum;
	    
	    /** Construct a thread */
	    public ServerThread(Socket socket, int clientNum) {
	      this.socket = socket;
	      this.clientNum = clientNum;
	    }
	    
	    /** Run a thread */
	    public void run() {
	      try {

	        // Continuously serve the client
			boolean flag=true;
	        while (flag) {
	        	
	        	String line;
	        	
	            BufferedReader reader = getReader(this.socket);

	        	 if ((line=reader.readLine()) == null){
	        	   flag = false;
	        	   continue;
	        	 }
	        	 
	        	 
	        	if(line.equals("1")) {
	        		String name = reader.readLine();
	        		int score = Integer.valueOf(reader.readLine());
	        		InsertRecord(new Player(name,score));
	        	}
	        	
	        	else if (line.equals("2")) {
	        		PrintWriter writer = getWriter(this.socket);
	        		ArrayList<Player> players = selectAll();
	        		writer.write(players.size()+"\n");
	        		for(Player player:players) {
	        			writer.write(player.getName()+"\n");
	        			writer.write(player.getScore()+"\n");

	        		}
	        		writer.flush();
	        		writer.write("null\n");
	        	}

	        }
			sockets.remove(this.socket);
			this.socket.close();

	        
	      }
	      catch(IOException ex) {
	        ex.printStackTrace();
	      }

	    }
	  }
	
	public static void main(String[] args) {
		Server server = new Server();
		//db.InsertRecord(new Player("JW",10));
		System.out.println(server.selectAll().get(0).getName());
		new Thread(server).start();
	}
}
